default platform driver. close source. Linux only at first
